public class Sprite extends Personne {
  int x;
  int y;
  int currentframe;
  PImage img;
  int anim_size;
  int step_size;
  Sprite idle;
  HitBox hitbox;
  UI bubble;

  List<String> prenoms = Arrays.asList(
    "Emma", "Léna", "Chloé", "Manon", "Camille",
    "Sarah", "Inès", "Clara", "Louise", "Eva",
    "Jade", "Slina", "Zoé", "Aurore", "Mila",
    "Lucie", "Julie", "Marine", "Amélia", "Yasmine",
    "Margot", "Clémence", "Margaux", "Anais", "Soriala",
    "Alizée", "Amandine", "Clothilde", "Hiba", "Romane"
    );

  Sprite(PImage img, int a_s, Cabine c, Station s ) {

    super("", c, s);
    this.name = prenoms.get((int) (Math.random() * prenoms.size()));
    this.x = 0;
    this.y = 0;
    this.currentframe = 0;
    this.img = img;
    this.anim_size = a_s;
    this.step_size = 4;
    this.hitbox = new HitBox(0, 0, a_s, a_s);
    this.bubble = new UI(0, 0, a_s, a_s, this.toString());
  }

  void anime(int dir) {
    //permet de lire l'animation d'un sprite
    int a_s = this.anim_size;
    int l = this.img.width / a_s;

    if (dir == 1)
      this.currentframe = (this.currentframe+1) %l;
    else if (dir == -1)
      this.currentframe = Math.abs(this.currentframe-1+l)%l;

    copy(img, a_s*this.currentframe, 0, a_s, a_s, this.x, this.y, a_s, a_s);
    //hitbox.draw(0);
  }

  void walk(int dir, int xoffset, int yoffset) {
    this.anime(dir);
    this.x += this.step_size*dir;
    this.hitbox.set(this.x+xoffset, this.y+yoffset, this.x+this.anim_size-xoffset, this.y+this.anim_size);
    //this.bubble.text = this.toString();
    this.bubble.set(this.x- (int) (textWidth(this.bubble.text)/2)+anim_size/2, this.y+20, this.x+this.anim_size, this.y+40);
  }

  void goTo(int end_x ) throws InitialisationException {
    if (this.idle == null) {
      throw new InitialisationException("attention l'animation d'idle n'a pas été implémentée dans Sprite.idle");
    }
    int dir = 1;

    this.idle.y = this.y;
    if (this.x+this.step_size <= end_x ) {
      walk(1, anim_size/3, anim_size/3);
    }
    if (this.x-this.step_size >= end_x ) {
      walk(-1, anim_size/3, anim_size/3);
      dir = -1;
    }
    if (end_x-this.step_size <= this.x  && this.x <= end_x+this.step_size) {
      this.idle.x = this.x;
      this.idle.y = this.y;
      this.idle.hitbox.set(this.x+48, this.y+60, this.x+this.anim_size-48, this.y+this.anim_size);
      this.bubble.set(this.x - (int) (textWidth(this.bubble.text)/2)+anim_size/2, this.y+20, this.x+this.anim_size, this.y+40);

      this.idle.anime(dir);
    }
  }
  public int getAnimationLength() {
    return this.img.width / anim_size;
  }

  /*
  @Override
   String toString() {
   
   return super.toString() + " " + String.format("Sprite {x : %d, y : %d}", x, y );
   }
   */

  @Override
    void buy(Titre_de_transport t) {
    try {
      super.buy(t);
    }
    catch(GuardException e) {
      print(e);
      return;
    }
    PImage an1 = null;
    PImage an2 = null;
    if (t == Titre_de_transport.Subscription) {
      an1 = sprites.get(2);
      an2 = sprites.get(3);
    } else if (t == Titre_de_transport.Ticket) {
      an1 = sprites.get(4);
      an2 = sprites.get(5);
    }
    if (an1 != null && an2 != null) {
      this.img = an1;
      this.idle.img = an2;
    }
  }
  @Override
    void shred() {
    try {
      super.shred();
    }
    catch(GuardException e) {
      print(e);
      return;
    }
    this.img = sprites.get(0);
    this.idle.img = sprites.get(1);
  }

  boolean atStation(Building station) {
    return this.x+3 > width-station.width+station.width/6;
  }
}
