import java.util.List;
import java.util.Arrays;

ArrayList<PImage> sprites = new ArrayList<PImage>();

SpriteSet waiting_queue = new SpriteSet();
SpriteSet enterer = new SpriteSet();

UI add_person_button, console, debug;
PImage bg,station;

int iter_on_waiting_queue = 0;
int iter_on_enterer = 0;
int sprite_size = 0;
int resize_factor = 1;
// logique métier
Cabine C1,C2;
Building A,B,C;

void setup() {
  // initialize work logique
  C1 = new Cabine('1');
  C2 = new Cabine('2');
  A = new Building('A', C2);
  B = new Building('B', C1);
  C = new Building('C', null);
  C1.position = B;
  C2.position = A;

  // size and bg size must be equals
  pixelDensity(1);
  size(1024, 768);
  frameRate(30);
  //fullScreen();
  
  // initialisation des sprites
  sprites.add(loadImage("assets/P1/Walk.png"));
  sprites.add(loadImage("assets/P1/Idle.png"));
  sprites.add(loadImage("assets/P2/Walk.png"));
  sprites.add(loadImage("assets/P2/Idle.png"));
  sprites.add(loadImage("assets/P3/Walk.png"));
  sprites.add(loadImage("assets/P3/Idle.png"));

  bg = loadImage("assets/nature_3/origbig.png");
  station = loadImage("assets/nature_3/Stations.png");
  A.set(station, width-station.width, height-station.height);
  //resizing
  if (resize_factor > 1){
    for (PImage e : sprites){
      e.resize((e.width/resize_factor),(e.height/resize_factor));  
    }
    A.img.resize((width/resize_factor),(height/resize_factor));
    A.set(station, width-station.width, height-station.height);
  }

  bg.resize(width, height);
  

  sprite_size = sprites.get(0).height;
  add_person_button = new UI(10,130,30,150, "Ajouter une personne");
  debug = new UI(10,160,30,180, "mount");
  
  // background configuration
}

int queue(int x, int iter, SpriteSet queue){
  if(iter == queue.size()){
    return 0;
  }
  queue.get(iter).goTo(x);
  
  
  return queue(x-queue.get(iter).anim_size/3, ++iter, queue);
}



void mousePressed() {
  // set actioin to add_person_button
  if (add_person_button.in()){
    waiting_queue.add(new Sprite(sprites.get(0),sprite_size,null,A));
    waiting_queue.get(waiting_queue.size()-1).idle = new Sprite(sprites.get(1),sprite_size,null,A);
    waiting_queue.get(waiting_queue.size()-1).x = -sprite_size;
    waiting_queue.get(waiting_queue.size()-1).y = height-waiting_queue.get((waiting_queue.size()-1)).img.height;
    waiting_queue.get(waiting_queue.size()-1).bubble.initAction();
    waiting_queue.get(waiting_queue.size()-1).step_size =  (waiting_queue.get(waiting_queue.size()-1).step_size/resize_factor) +2;
    A.persons.add(waiting_queue.get(waiting_queue.size()-1));
    println("persons à la cabine 1" + A.persons);
  }
  for (Sprite s : waiting_queue){
 
    //action to button
    if (s.bubble.pop_up_elements.get(0).in()){
      s.buy(Titre_de_transport.Ticket);
    }
    if (s.bubble.pop_up_elements.get(1).in()){
      s.buy(Titre_de_transport.Subscription);
    }
    if (s.bubble.pop_up_elements.get(2).in()){
      s.shred();
    }
    if(s.canEnter(A) && s.bubble.pop_up_elements.get(3).in()){
      enterer.add(s);
      waiting_queue.remove(s);
      
    }
    // mask on click
    if (!s.hitbox.in()){
      s.bubble.text = "";
      s.bubble.show_pop_up = false;
      s.hitbox.clickable = true;
      for(UI e : s.bubble.pop_up_elements){
        e.clickable = false;
      }
    }
    //show button on click
    if (s.hitbox.in()){
      s.bubble.popUpMenu();
      s.bubble.text = s.toString();
      s.bubble.show_pop_up = true;
      s.hitbox.clickable = false;
      for(UI e : s.bubble.pop_up_elements){
        e.clickable = true;
      }
    }

    if(debug.in()){
    try{
    C2.mount(s);}
      catch(GuardException e ){
        println(e);
      }
    }
  }
  
}

//draw function 
void draw() {
  //Background  
  image(bg, 0, 0);
  A.draw();


  //ForeGround
  //faire la file
  iter_on_waiting_queue = queue(width-A.width+A.width/6, iter_on_waiting_queue, waiting_queue);
  iter_on_enterer = queue(width-A.width+A.width/6, iter_on_enterer,enterer);


  //UI
  add_person_button.draw(20);
  debug.draw(20);
  for(Sprite s : waiting_queue){
    //show information bubble
    s.bubble.draw(15);
    // show action menu
    if (s.bubble.show_pop_up){
      s.bubble.popUpMenu();
    }
  }
  for(Sprite s : enterer){
    if(s.atStation(A)){
      enterer.remove(s);
    }
  }
}  
// selection de l'action en faisant des randoms sur si la précondition est vérifiée ou pas dans une liste précise et pas tous pour ne pas perdre des ressources inutillements
