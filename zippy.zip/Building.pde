public class Building extends Station {
  int x, y, width, height;
  PImage img;
  Building(char id, Cabine c, PImage img, int x, int y) {
    super( id, c);
    this.x = x;
    this.y = y;
    this.height = img.height;
    this.width = img.width;
    this.img = img;
  }
  Building(char id, Cabine c) {
    super( id, c);
    this.x = 0;
    this.y = 0;
    this.height = 0;
    this.width = 0;
    this.img = null;
  }

  void draw() {
    image(this.img, this.x, this.y, this.width, this.height);
  }

  void set(PImage img, int x, int y) {
    this.x = x;
    this.y = y;
    this.height = img.height;
    this.width = img.width;
    this.img = img;
  }
}
