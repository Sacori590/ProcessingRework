import java.util.ArrayList;

public class téléphérique {
    void main(String[] args) {
        System.out.println("hello");
        initTest();
    }

    void initTest() {
        // initialisation des variables
        Cabine C1 = new Cabine('1');
        Cabine C2 = new Cabine('2');

        Station A = new Station('A', C2);
        Station B = new Station('B', C1);
        Station C = new Station('C', null);
        C1.position = B;
        C2.position = A;

        // créer un set de personnes
        ArrayList<Personne> SetPersonne = new ArrayList<Personne>();
        for (int i = 0; i < 100; i++) {
            SetPersonne.add(new Personne(i, null, A));
        }

        // placer les personnes à la cabine 1 et donc la Station A
        for (Personne p : SetPersonne) {
            A.add(p);
        }

        // prenons 2 personnes
        Personne TICKET = SetPersonne.get(0);
        Personne VIP = SetPersonne.get(1);

        // acheter un ticket pour pour l'un et un abonnement pour l'autre
        System.out.println(TICKET.toString());
        TICKET.buy(Titre_de_transport.Ticket);
        VIP.buy(Titre_de_transport.Subscription);

        System.out.println(TICKET.toString());
        // essayons de faire monter Monsieur Ticket Avant Monsieur VIP
        try {
            C2.mount(TICKET);
        } catch (GuardException e) {
            System.out.println("\033[38;5;1m" + e + "\033[0m");
        } // -> guard violé

        // laisson VIP monter
        C2.mount(VIP);
        C2.mount(TICKET);
        // guarde non violé

        // avancer cabine
        System.out.println(TICKET.toString());
        System.out.println(VIP.toString());
        System.out.println(A.toString());
        C1.move(C);
        C2.move(B);
        System.out.println(B.toString());
        System.out.println(C1.toString());
        System.out.println(C2.toString());

        // descendre
        C2.dismount(TICKET);
        C2.dismount(VIP);
        System.out.println(TICKET.toString());
        System.out.println(VIP.toString());
        System.out.println(B.toString());

        // acheter un ticket pour VIP qui en a déjà un

        try {
            VIP.buy(Titre_de_transport.Ticket);
        } catch (GuardException e) {
            System.out.println("\033[38;5;1m" + e + "\033[0m");
        }

    }

}